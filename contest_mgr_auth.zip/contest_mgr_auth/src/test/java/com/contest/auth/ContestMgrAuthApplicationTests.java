package com.contest.auth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContestMgrAuthApplicationTests {

	@Test
	void contextLoads() {
	}

}
