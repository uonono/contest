package com.contest.gateway;

import javax.net.ssl.X509TrustManager;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

public class CustomTrustManager implements X509TrustManager {

    @Override
    public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
        // 实现自定义的客户端信任逻辑
    }

    @Override
    public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
        // 实现自定义的服务器信任逻辑
    }

    @Override
    public X509Certificate[] getAcceptedIssuers() {
        return new X509Certificate[0]; // 返回一个空的数组，表示接受所有的证书
    }

    public static X509TrustManager[] getCustomTrustManagers() {
        return new X509TrustManager[]{new CustomTrustManager()};
    }
}
