package com.contest.gateway;

import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;
import reactor.netty.tcp.SslProvider;

import javax.net.ssl.SSLContext;

public class WebClientConfig {

    public WebClient createWebClient() throws Exception {
        SSLContext sslContext = SSLContextConfig.createCustomSSLContext();

        HttpClient httpClient = HttpClient.create()
                .secure(sslContextSpec -> sslContextSpec.sslContext((SslProvider.ProtocolSslContextSpec) sslContext));

        return WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .build();
    }
}
