package com.contest.gateway;

import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;

import javax.net.ssl.SSLContext;
import java.security.PrivateKey;

public class NettyServerConfig {

    public SslContext createNettySslContext() throws Exception {
        SSLContext sslContext = SSLContextConfig.createCustomSSLContext();

        return SslContextBuilder.forServer((PrivateKey) sslContext)
                .build();
    }
}
