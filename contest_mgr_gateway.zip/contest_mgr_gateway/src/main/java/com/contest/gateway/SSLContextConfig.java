package com.contest.gateway;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import java.security.SecureRandom;

public class SSLContextConfig {

    public static SSLContext createCustomSSLContext() throws Exception {
        // 获取自定义的TrustManager
        TrustManager[] trustManagers = CustomTrustManager.getCustomTrustManagers();

        // 创建并初始化SSLContext
        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(null, trustManagers, new SecureRandom());

        return sslContext;
    }
}
