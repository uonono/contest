package com.contest.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContestMgrGatewayApplication {

    public static void main(String[] args) {
        SpringApplication.run(ContestMgrGatewayApplication.class, args);
    }

}
