package com.contest.gateway.controllor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
/**
* @Author: cy
* @Date: 2024/8/22 下午2:30
* @Description: 粗略实现自定义webFlux网关，绕过springCloud的https证书检测（java的）
*/
@RestController
@RequestMapping("/api")
public class GatewayController {

    private final WebClient webClient;

    @Autowired
    public GatewayController(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.baseUrl("https://localhost:8768").build();
    }

    @GetMapping("/userInfo")
    public Mono<ResponseEntity<String>> getUserInfo() {
        return this.webClient.get()
                .uri("/userInfo")
                .retrieve()
                .toEntity(String.class);
    }
}
